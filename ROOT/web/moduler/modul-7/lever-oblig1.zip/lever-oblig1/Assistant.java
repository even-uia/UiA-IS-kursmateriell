import java.util.Random;


/**
 * A teaching Assistant that tries to find his way between two
 * rooms (by taking random exits from his current room.
 *
 * @author Even
 * @version 2008
 */
public class Assistant {
    private Room currentRoom;
    private Room target, oldTarget;
    private Random rnd;

    /**
     * Constructor for objects of class Assistant.
     * @param room the starting room for the teaching assistant.
     * @param target the room he will try to move to.
     */
    public Assistant(Room room, Room target) {
        currentRoom = room;
        this.target = target;
        oldTarget = room;
        rnd = new Random();
    }
    
    /** Move to another room. */
    public void move() {
        if (currentRoom == target) { // he's found it - turn around
            target = oldTarget;
            oldTarget = currentRoom;
        }
        else {
            Object[] exits = currentRoom.getExits().toArray();
            int index = rnd.nextInt(exits.length+1);
            if (index < exits.length)
                currentRoom = currentRoom.getExit((String)(exits[index]));
        }
    }
    
    
    /** @return the current room. */
    public Room getCurrentRoom() {
        return currentRoom;
    }
}
