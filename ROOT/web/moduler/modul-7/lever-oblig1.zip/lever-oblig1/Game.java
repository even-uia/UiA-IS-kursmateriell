/**
 *  This class is the main class of the "World of Zuul" application. 
 *  "World of Zuul" is a very simple, text based adventure game.  Users 
 *  can walk around some scenery. That's all. It should really be extended 
 *  to make it more interesting!
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @version 2006.03.30
 */

public class Game 
{
    private Parser parser;

    private Room utgang, kantine, bokhandel, vrimlehall, bibliotek, gangbro, lab, auditorium;
    private Room currentRoom;

    private Assistant assistant;
    
    private boolean hasBook, heardLecture, visitedLab, askedAssistant, hasHandedIn;
        
    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
        createRooms();
        parser = new Parser();
    }

    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
      
        // create the rooms
        utgang = new Room("nederst i en lang trapp");
        kantine = new Room("i kantina");
        bokhandel = new Room("i bokhandelen");
        vrimlehall = new Room("i vrimlehallen");
        bibliotek = new Room("i biblioteket");
        gangbro = new Room("p� gangbrua over vrimlehallen");
        lab = new Room("p� PC-laben");
        auditorium = new Room("i et auditorium");
        
        // initialise room exits
        utgang.setExit("opp", vrimlehall);
        utgang.setExit("syd", kantine);
        utgang.setExit("nord", bokhandel);
        kantine.setExit("nord", utgang);
        bokhandel.setExit("syd", utgang);
        
        vrimlehall.setExit("ned", utgang);
        vrimlehall.setExit("syd", bibliotek);
        vrimlehall.setExit("opp", gangbro);
        bibliotek.setExit("nord", vrimlehall);
        bibliotek.setExit("ned", kantine);
        
        gangbro.setExit("ned", vrimlehall);
        gangbro.setExit("syd", lab);
        gangbro.setExit("nord", auditorium);
        lab.setExit("nord", gangbro);
        lab.setExit("ned", kantine);
        auditorium.setExit("syd", gangbro);
        auditorium.setExit("ned", bokhandel);

        currentRoom = utgang;  // start game outside
        assistant = new Assistant(lab, kantine);
    }

    
    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play() 
    {  
        currentRoom = utgang;  // start game outside
        assistant = new Assistant(lab, kantine);
        hasBook = heardLecture = visitedLab = askedAssistant = hasHandedIn = false;
        
        printWelcome();

        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.
                
        boolean finished = false;
        while (! finished) {
            Command command = parser.getCommand();
            finished = processCommand(command);
            assistant.move();

            // check triggers
            finished = finished || checkStatus();
        }
        System.out.println("Takk for at du spilte. Ha det bra!");
    }
    
    
    /** Check game status. Returns true if game over */
    private boolean checkStatus() {
        if (currentRoom == bokhandel && !hasBook) {
            System.out.println("Dere ser l�reboka i hylla og kj�per den.");
            System.out.println("Jens leser den og sier\n- Dette m� vi pr�ve p� laben.");
            hasBook = true;
        }
        else if (currentRoom == bibliotek && !hasBook) {
            System.out.println("Du ser l�reboka i hylla og l�ner den.");
            System.out.println("Du leser boka og f�r lyst til � pr�ve det du har l�rt p� laben.");
            hasBook = true;
        }
        else if (currentRoom == auditorium) {
            if (heardLecture) System.out.println("Jens sier:\n- Vi g�r heller p� laben.");
            else if (hasBook) {
                System.out.println("Jens sier\n- Det ble litt klarere n�. Vi g�r p� laben og pr�ver igjen.");
                heardLecture = true;
            }
            else {
                System.out.println("Jens sier:\n- Jeg skj�nner ingenting. Vi burde lese boka f�rst.");
            }
        }
        else if (currentRoom == lab) {
            if (hasBook) {
                visitedLab = true;
                if (askedAssistant && heardLecture) {
                    System.out.println("Dette g�r jo som en dr�m, Jens.");
                    System.out.println("Gratulerer! Dere har levert obligen.");
                    return true;
                }
                else if (askedAssistant) {
                    System.out.println("Dere pr�ver tipset fra hjelpel�reren, men f�r");
                    System.out.println("f�r det enn� ikke helt til. Jens sier\n- Kanskje vi skulle g� p� forelesning.");
                }
                else if (heardLecture) {
                    System.out.println("Dere pr�ver det dere l�rte p� forelesning, men st�r fast etter en stund.");
                    System.out.println("Jens sier\n- Vi m� sp�rre hjelpel�reren.");
                }
                else {
                    System.out.println("Dere sitter ned med l�reboka og pr�veer � l�se oppgaven.");
                    System.out.println("Jens sier\n- Jeg tror vi m� sp�rre noen om hjelp?");                        
                }
            }
            else {
                System.out.println("Dere sitter ned ved en PC, men vet ikke helt hva dere skal gj�re.");
                System.out.println("Jens sier\n- Kanskje vi skulle f� tak i l�reboka...?");
            }
        }

        if (assistant.getCurrentRoom() == currentRoom) {
            System.out.println("Hjelpel�reren er her.");
            if (visitedLab && !askedAssistant) {
                System.out.println("Dere forklarer problemet og f�r noen tips.");
                System.out.println("Jens sier\n- Vi g�r tilbake til laben og pr�ver igjen.");
                askedAssistant = true;
            }
        }
        
        return false;
    }

    
    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Velkommen til spillet \"Oblig\"!");
        System.out.println("");
        System.out.println("M�let ditt er � f� levert obligen i IS-102");
        System.out.println("sammen med din trofaste kamerat Jens.");
        System.out.println();
        System.out.println(currentRoom.getLongDescription());
        printHelp();
    }


    /**
     * Given a command, process (that is: execute) the command.
     * @param command The command to be processed.
     * @return true If the command ends the game, false otherwise.
     */
    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false;

        CommandWord commandWord = command.getCommandWord();

        if(commandWord == CommandWord.UNKNOWN) {
            System.out.println("Hva er det egentlig du mener...");
            return false;
        }

        if (commandWord == CommandWord.HELP) {
            printHelp();
        }
        else if (commandWord == CommandWord.GO) {
            goRoom(command);
        }
        else if (commandWord == CommandWord.HINT) {
            hint();
        }
        else if (commandWord == CommandWord.QUIT) {
            wantToQuit = quit(command);
        }
        // else command not recognised.
        return wantToQuit;
    }

    // implementations of user commands:

    /**
     * Print out some help information.
     * Here we print some stupid, cryptic message and a list of the 
     * command words.
     */
    private void printHelp() 
    {
        System.out.println("Kommandoene du kan bruke:");
        parser.showCommands();
    }
    
    /**
     * Print a hint.
     */
    private void hint() {
        if (! hasBook) {
            System.out.println("- Hvordan skal vi f� til dette Jens?");
            System.out.println("- Kanskje vi burde lese boka.");
        }
        else if (! heardLecture) {
            System.out.println("- Jeg skj�nner ikke alt som st�r i boka Jens?");
            System.out.println("- Kanskje det hjelper � g� p� forelesning.");
        }
        else if (! visitedLab) {
            System.out.println("- Hva gj�r vi n� Jens?");
            System.out.println("- Vi g�r p� laben.");
        }
        else if (! askedAssistant) {
            System.out.println("- Hva gj�r vi n� Jens?");
            System.out.println("- Vi m� sp�rre hjelpel�reren. Jeg s� ham "+assistant.getCurrentRoom()+".");
        }
        else if (! hasHandedIn) {
            System.out.println("- Hva gj�r vi n� Jens?");
            System.out.println("- Vi m� g� p� laben og gj�re oss ferdig.");
        }
        System.out.println(); // extra blank line
    }

    /** 
     * Try to go to one direction. If there is an exit, enter the new
     * room, otherwise print an error message.
     */
    private void goRoom(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know where to go...
            System.out.println("G� javel, men hvor?");
            return;
        }

        String direction = command.getSecondWord();

        // Try to leave current room.
        Room nextRoom = currentRoom.getExit(direction);

        if (nextRoom == null) {
            System.out.println("Du kan ikke g� i den retningen!");
        }
        else {
            currentRoom = nextRoom;
            System.out.println(currentRoom.getLongDescription());
        }
    }

    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) {
            System.out.println("Ha hva da?");
            return false;
        }
        else {
            return true;  // signal that we want to quit
        }
    }
    
    
    public static void main(String[] args) {
        Game g = new Game();
        g.play();
    }
}
