
/**
 * Common superclass for everything in the game world.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class GameItem
{
    
    /** The name, or short description of the item */
    private String name;
    
    /** A longer description of the item. */
    private String description;
    
    
    public GameItem(String name, String description) {
        this.name = name;
        this.description = description;
    }
    
    
    public String getName() {
        return name;
    }
    
    
    public String getDescription() {
        return description;
    }
    
    
    /** Return true if this item can be used by the player */
    public boolean isUsable() {
        return false;
    }
    
    
    /** Use this item. Return true if successful, false if it fails. */
    public boolean use() {
        return false;
    }


    // Here are String constants for all text displayed
    // by the game.
    // Using these constants makes it easier to translate
    // the game (this is the only file that needs changing)
    // and it ensures that the language is consistent throughout

    // Locations
    public final static String ENTR_NAME = "inngangen";
    public final static String ENTR_DESC = "Du st�r ved inngange, i bunnen av ei lang trapp.";
    public final static String ENTR_PREP = "ved";
    public final static String CAFE_NAME = "kantina";
    public final static String CAFE_DESC = "Her kan du f� kaffe og noe � spise.";
    public final static String CAFE_PREP = "i";
    public final static String SHOP_NAME = "bokhandelen";
    public final static String SHOP_DESC = "Her kan du kj�pe b�ker. De har l�reboka.";
    public final static String SHOP_PREP = "i";
    public final static String HALL_NAME = "Vrimlehallen";
    public final static String HALL_DESC = "Dette er en stor hall med glasstak.";
    public final static String HALL_PREP = "i";
    public final static String LIB_NAME = "biblioteket";
    public final static String LIB_DESC = "Her kan du l�ne b�ker. De har l�reboka.";
    public final static String LIB_PREP = "i";
    public final static String BRDG_NAME = "gangbrua";
    public final static String BRDG_DESC = "Du ser ned p� Vrimlehallen.";
    public final static String BRDG_PREP = "p�";
    public final static String LAB_NAME = "laben";
    public final static String LAB_DESC = "Her er det mange PCer. Du kan jobbe med oppgaven her.";
    public final static String LAB_PREP = "p�";
    public final static String AUD_NAME = "auditoriet";
    public final static String AUD_DESC = "Hallgeir og Even snakker om programmering.";
    public final static String AUD_PREP = "i";

    // Directions
    public final static String DIR_UP = "opp";
    public final static String DIR_DOWN = "ned";
    public final static String DIR_EAST = "�st";
    public final static String DIR_WEST = "vest";
    public final static String DIR_NORT = "nord";
    public final static String DIR_SOUT = "s�r";
    
    // Commands
    public final static String HELP_NAME = "hjelp";
    public final static String HELP_DESC = "hjelp - Skriv ut liste over kommandoer,\n"+
                                           "hjelp <kommando> - Vis hjelp for angitt kommando";
    public final static String GO_NAME = "g�";
    public final static String GO_DESC = "g� <retning> - G� til naborommet i angitt retning.";
    public final static String HINT_NAME = "hint";
    public final static String HINT_DESC = "hint - F� et hint om hva du m� gj�re for � komme videre.";
    public final static String QUIT_NAME = "avslutt";
    public final static String QUIT_DESC = "avslutt - Avslutt spillet.";
    
    // Assistant
    public final static String ASSISTANT_NAME = "hjelpel�reren";
    public final static String ASSISTANT_DESC = "Han retter obligene.";
    
    // Player
    public final static String PLAYER_NAME = "Du";
    public final static String PLAYER_DESC = "Du er en student som skal levere obligen i programmering.";
    
    
    // Messages
    public final static String MSG_NO_CMD = "Finner ikke kommandoen ";
    public final static String MSG_AVAIL_CMD = "Kommandoene du kan bruke er:";
    public final static String MSG_HELP_INFO = "Bruk 'hjelp <kommando>' for � f� mer hjelp.";
    public final static String MSG_NOEXIT = "Du kan ikke g� ";
    public final static String MSG_NOEXIT_END = " herfra!";
    public final static String MSG_NODIR = "G� hvor?";
    public final static String MSG_BYE = "Takk for at du spilte. Ha det bra!";
    public final static String MSG_WELCOME = "Velkommen til spillet \"Oblig\"!\n"
            +"\nM�let ditt er � f� levert obligen i IS-102";    
    public final static String MSG_BUY_BOOK = "Dere ser l�reboka i hylla og kj�per den.";
    public final static String MSG_LOAN_BOOK = "Du ser l�reboka i hylla og l�ner den.";
    public final static String MSG_LECTURE = "Du forst�r mye mer etter forelesning. Pr�v deg p� laben igjen!";
    public final static String MSG_LECTURE_REP = "Dette h�res kjent ut. Du b�r heller g� p� laben.";
    public final static String MSG_LECTURE_NOBOOK = "Dette var vanskelig. Du burde skaffe boka og lese den.";
    public final static String MSG_FINISHED = "Med alt du har l�rt g�r det lett � gj�re ferdig obligen.\n"
            +"Gratulerer! Du har greid det!";
    public final static String MSG_NOLECTURE = "Du pr�ver deg p� obligen igjen, men f�r det ikke til.\n"
            +"Pr�v � g� p forelesning.";
    public final static String MSG_NOASSISTANT = "Du pr�ver deg p� obligen igjen, men st�r fast.\n"
            +"Du burde sp�rre hjelpel�reren.";
    public final static String MSG_NEED_HELP = "Du pr�ver deg p� obligen, men f�r det ikke til.\n"
            +"Du m� finne noen du kan sp�rre om hjelp.";
    public final static String MSG_NOBOOK = "Du pr�ver deg p� obligen, men vet ikke hvor du skal begynne.\n"
            +"Det ville sikkert hjelpe � skaffe seg boka...";
    public final static String MSG_ASSISTANT = "Hjelpel�reren gir deg noen hint.\n"
            +"G� tilbake til laben og pr�v igjen.";
   
    // Hint
    public final static String HINT_BOOK = "Du burde lese boka.\nDen finnes i bokhandelen og p� biblioteket.";
    public final static String HINT_LECTURE = "Du burde g� p� forelesning. Finn auditoriet.";
    public final static String HINT_LAB = "Du m� g� p� laben for � gj�re obligen.";
    public final static String HINT_ASSISTANT = "Du m� sp�rre hjelpel�reren.";
    public final static String Xy = "";

}
