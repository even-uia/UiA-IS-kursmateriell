
/**
 * Write a description of class Actor here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public abstract class Actor extends GameItem
{
    private Location currentLocation;
    
    
    public Actor(String name, String description, Location loc) {
        super(name, description);
        setLocation(loc);
    }
    
    
    public Location getLocation() {
        return currentLocation;
    }
    
    
    /** When moving to another location, we must remove ourselves
     * from the actor list in the old location, and add to the new.
     */
    public void setLocation(Location loc) {
        if (currentLocation != null) currentLocation.removeActor(this);
        currentLocation = loc;
        if (currentLocation != null) currentLocation.addActor(this);
    }
    
    
    public abstract void move();
}
