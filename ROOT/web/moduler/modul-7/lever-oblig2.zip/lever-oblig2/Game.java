import java.util.ArrayList;



/**
 *  This class is the main class of the 'Hand in the assignment' application.
 *  'Hand in the assignment' is a very simple, text based adventure game.  Users
 *  can walk around some scenery. That's all. It should really be extended
 *  to make it more interesting!
 *
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 *
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 *
 * @author  Michael Kolling and David J. Barnes
 * @version 2006.03.30
 */

public class Game
{
    private World world;


    /**
     * Create the game.
     */
    public Game()
    {
    }


    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play()
    {
        World world = new World();
        ArrayList<Actor> actors = new ArrayList<Actor>();
        Player player = new Player(world.getLocation(GameItem.ENTR_NAME));
        actors.add(player);
        actors.add(new Assistant(world.getLocation(GameItem.LAB_NAME), world.getLocation(GameItem.CAFE_NAME)));

        printWelcome();

        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.

        boolean finished = player.checkStatus();
        while (! finished) {
            for (Actor a : actors) a.move();

            // check triggers
            finished = player.checkStatus();
        }
        System.out.println(GameItem.MSG_BYE);
    }


    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println(GameItem.MSG_WELCOME);
        System.out.println();
    }


    public static void main(String[] args) {
        Game g = new Game();
        g.play();
    }
}
