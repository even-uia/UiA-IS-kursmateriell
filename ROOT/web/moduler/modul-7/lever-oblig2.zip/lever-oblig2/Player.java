import java.util.ArrayList;



/**
 * The Player class handles all user interaction. When it is the user's
 * turn to move, the Player object reads a command line from the keyboard,
 * parses it, and executes it.
 * 
 * The player object also keeps track of the user's progress in the game.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Player extends Actor
{
    private CommandParser parser;
    private CommandList commands;

    // Game state
    private boolean hasBook, heardLecture, visitedLab, askedAssistant;
    private boolean gameOver;
    
    public Player(Location loc) {
        super(PLAYER_NAME, PLAYER_DESC, loc);
            
        parser = new CommandParser();
        commands = CommandList.getInstance();
        hasBook = heardLecture = visitedLab = false;
        askedAssistant = gameOver = false;
    }
    
    
    /** Execute one command. */
    public void move() {
        ArrayList<String> cmdLine = parser.getCommand();
        Command cmd = commands.getCommand(cmdLine.get(0));
        
        if (cmd == null) cmd = commands.getCommand(HELP_NAME);
        cmd.execute(this, cmdLine);
    }
    
    
    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }
    
    
    /** Return true if the player has won the game,
     * or wants to quit.
     */
    public boolean checkStatus() {
        System.out.println(getLocation().getLongDescription());
        
        if (getLocation().getName() == SHOP_NAME && !hasBook) {
             System.out.println(MSG_BUY_BOOK);
             hasBook = true;
         }
         else if (getLocation().getName() == LIB_NAME  && !hasBook) {
             System.out.println(MSG_LOAN_BOOK);
             hasBook = true;
         }
         else if (getLocation().getName() == AUD_NAME) {
             if (heardLecture) System.out.println(MSG_LECTURE_REP);
             else if (hasBook) {
                 System.out.println(MSG_LECTURE);
                 heardLecture = true;
             }
             else {
                 System.out.println(MSG_LECTURE_NOBOOK);
             }
         }
         else if (getLocation().getName() == LAB_NAME) {
             if (hasBook) {
                 visitedLab = true;
                 if (askedAssistant && heardLecture) {
                     System.out.println(MSG_FINISHED);
                     gameOver = true;
                 }
                 else if (askedAssistant) {
                     System.out.println(MSG_NOLECTURE);
                 }
                 else if (heardLecture) {
                     System.out.println(MSG_NOASSISTANT);
                 }
                 else {
                     System.out.println(MSG_NEED_HELP);                        
                 }
             }
             else {
                 System.out.println(MSG_NOBOOK);
             }
         }
 
         if (getLocation().getActor(ASSISTANT_NAME) != null) {
             if (visitedLab && !askedAssistant) {
                 System.out.println(MSG_ASSISTANT);
                 askedAssistant = true;
             }
         }
        
        return gameOver;
    }
    
    
    /** These are needed for the hint command. */
    public boolean hasBook() { return hasBook; }
    public boolean heardLecture() { return heardLecture; }
    public boolean visitedLab() { return visitedLab; }
    public boolean askedAssistant() { return askedAssistant; }
    public boolean gameOver() { return gameOver; }
}
