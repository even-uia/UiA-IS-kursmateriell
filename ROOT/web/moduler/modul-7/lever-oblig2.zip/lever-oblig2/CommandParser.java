import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * 
 */
public class CommandParser 
{
    private Scanner reader;         // source of command input

    /**
     * Create a parser to read from the terminal window.
     */
    public CommandParser() 
    {
        reader = new Scanner(System.in);
    }

    /**
     * @return The next command from the user.
     */
    public ArrayList<String> getCommand() 
    {
        String inputLine;   // will hold the full input line
        String word = null;

        System.out.print("> ");     // print prompt
        inputLine = reader.nextLine();

        Scanner tokenizer = new Scanner(inputLine);
        ArrayList<String> words = new ArrayList<String>();
        while (tokenizer.hasNext()) words.add(tokenizer.next());
        return words;
    }
}
