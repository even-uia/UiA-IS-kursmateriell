import java.util.Set;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * A Location represents a place in the game world.  It is
 * connected to other locations via exits.  For each existing exit, the location
 * stores a reference to the neighboring location.
 *
 * @author  Even
 */

public class Location extends GameItem
{
    /** Adjacent rooms */
    private HashMap<String, Location> exits;
    
    /** Actors in this room */
    private HashMap<String, Actor> actors;

    /** Preposition to use */
    private String preposition;

    /**
     * Create a room described "description". Initially, it has
     * no exits. "description" is something like "a kitchen" or
     * "an open court yard".
     * @param description The room's description.
     */
    public Location(String name, String description, String preposition)
    {
        super(name, description);
        this.preposition = preposition;
        exits = new HashMap<String, Location>();
        actors = new HashMap<String, Actor>();
    }


    /**
     * Define an exit from this room.
     * @param direction The direction of the exit.
     * @param neighbor  The room to which the exit leads.
     */
    public void setExit(String direction, Location neighbor)
    {
        exits.put(direction, neighbor);
    }

    /**
     * @return The short description of the room
     * (the one that was defined in the constructor).
     */
    public String getShortDescription()
    {
        return "Du er "+preposition+" "+getName();
    }

    /**
     * Return a description of the room in the form:
     *     You are in the kitchen.
     *     Exits: north west
     * @return A long description of this room
     */
    public String getLongDescription()
    {
        return getShortDescription() + "\n"
            + getDescription()+"\n"
            + getActorString()
            + getExitString()+ "\n";
    }


    /**
     * Get the exit directions.
     * @return the set of exit keys.
     */
    public Set<String> getExits() {
        return exits.keySet();
    }


    /**
     * Return a string describing the room's exits, for example
     * "Exits: north west".
     * @return Details of the room's exits.
     */
    private String getExitString()
    {
        String returnString = "Utganger: ";
        for(String exit : getExits()) {
            returnString += " " + exit;
        }
        return returnString;
    }

    /**
     * Return the room that is reached if we go from this room in direction
     * "direction". If there is no room in that direction, return null.
     * @param direction The exit's direction.
     * @return The room in the given direction.
     */
    public Location getExit(String direction)
    {
        return exits.get(direction);
    }


    public String toString() {
        return getName();
    }
    
    
    public void addActor(Actor a) {
        actors.put(a.getName(), a);
    }

    
    public Actor getActor(String name) {
        return actors.get(name);
    }


    public void removeActor(Actor a) {
        actors.remove(a.getName());
    }
    
    
    public String getActorString() {
        if (actors.size() > 0) {
            StringBuilder buf = new StringBuilder();
            for (String name : actors.keySet()) {
                if (name != PLAYER_NAME) {
                    buf.append(name);
                    buf.append(" er her.\n");
                }
            }
            return buf.toString();
        }
        else return "";
    }
}

