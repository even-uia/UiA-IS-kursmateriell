import java.util.ArrayList;



/**
 * This class is part of the game 'Hand in the assignment'.
 *
 * The command class represents commands that can be executed by an interactive
 * player. It is an abstract class. The actual commands are executed as
 * subclasses.
 *
 * @author  Even �by Larsen
 * @version 2006.03.30
 */

public abstract class Command extends GameItem {

    /**
     * Initialize and register a new command.
     *
     * @param name the command name.
     * @param description command description.
     */
    public Command(String name, String description) {
        super(name, description);
        CommandList.getInstance().addCommand(name, this);
    }


    /** Utf�r denne kommandoen for en bestemt spiller */
    public abstract void execute(Player p, ArrayList<String> commandLine);


    /** Create the game commands.
     * The commands are created as anonymous subclasses of command
     * to avoid cluttering the class diagram even more.
     */
    public static void createCommands() {

        // hjelp
        new Command(HELP_NAME, HELP_DESC) {
            public void execute(Player p, ArrayList<String> cmdLine) {
                CommandList commands = CommandList.getInstance();
                if (cmdLine.size() == 2) {
                    String cmdName = cmdLine.get(1);
                    Command cmd = commands.getCommand(cmdName);
                    if (cmd != null) System.out.println(cmd.getDescription());
                    else System.out.println(MSG_NO_CMD+cmdName);
                }
                else {
                    System.out.println(MSG_AVAIL_CMD);
                    commands.showAll();
                    System.out.println(MSG_HELP_INFO);
                }
            }
        };

        // g�
        new Command(GO_NAME, GO_DESC) {
            public void execute(Player p, ArrayList<String> cmdLine) {
                if (cmdLine.size() == 2) {
                    String dir= cmdLine.get(1);
                    Location newLoc = p.getLocation().getExit(dir);

                    if (newLoc != null) {
                        p.setLocation(newLoc);
                    }
                    else {
                        System.out.println(MSG_NOEXIT+dir+MSG_NOEXIT_END);
                    }
                }
                else {
                    System.out.println(MSG_NODIR);
                    System.out.println(getDescription());
                }
            }
        };

        // hint
        new Command(HINT_NAME, HINT_DESC) {
            public void execute(Player p, ArrayList<String> cmdLine) {
                if (! p.hasBook()) {
                    System.out.println(HINT_BOOK);
                }
                else if (! p.heardLecture()) {
                    System.out.println(HINT_LECTURE);
                }
                else if (! p.visitedLab()) {
                    System.out.println(HINT_LAB);
                }
                else if (! p.askedAssistant()) {
                    System.out.println(HINT_ASSISTANT);
                }
                else {
                    System.out.println(HINT_LAB);
                }
                System.out.println(); // extra blank line
            }
        };

        // quit
        new Command(QUIT_NAME, QUIT_DESC) {
            public void execute(Player p, ArrayList<String> cmdLine) {
                p.setGameOver(true);
            }
        };
    }
}

