package game.commands;

import java.util.ArrayList;
import game.Player;
import game.world.Location;



/**
 * Write a description of class Go here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Go extends Command
{

    public Go() {
        super(GO_NAME, GO_DESC);
    }
    
    
    public void execute(Player p, ArrayList<String> cmdLine) {
        if (cmdLine.size() == 2) {
            String dir= cmdLine.get(1);
            Location newLoc = p.getLocation().getExit(dir);
            
            if (newLoc != null) {
                p.setLocation(newLoc);
                if (p.hasVisited(newLoc))
                    System.out.println(newLoc.getShortDescription());
                else System.out.println(newLoc.getLongDescription());
            }
            else {
                System.out.println(GO_NOEXIT_MSG+dir+GO_NOEXIT_MSG2);
            }
        }
        else {
            System.out.println(GO_NODIR_MSG);
            System.out.println(getDescription());
        }
    }
}
