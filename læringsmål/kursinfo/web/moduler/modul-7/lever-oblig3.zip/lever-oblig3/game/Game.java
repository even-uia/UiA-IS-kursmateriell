package game;

import java.util.ArrayList;
import game.items.GameItem;
import game.world.World;



/**
 *  This class is the main class of the 'Hand in the assignment' application.
 *  'Hand in the assignment' is a very simple, text based adventure game.  Users
 *  can walk around some scenery. That's all. It should really be extended
 *  to make it more interesting!
 *
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 *
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 *
 * @author  Michael Kolling and David J. Barnes
 * @version 2006.03.30
 */

public class Game implements GameConstants
{
    /**
     * Create the game.
     */
    public Game() {
    }


    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play()
    {
        World world = new World();
        ArrayList<Actor> actors = new ArrayList<Actor>();
        Player player = new Player(world.getLocation(ENTR_NAME));
        actors.add(player);
        actors.add(new Assistant(world.getLocation(LAB_NAME), world.getLocation(CAFE_NAME)));

        printWelcome();
        System.out.println(player.getLocation().getLongDescription());

        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.
        while (! player.gameOver()) {
            for (Actor a : actors) a.move();
        }
        System.out.println(MSG_BYE);
    }


    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println(MSG_WELCOME);
    }


    public static void main(String[] args) {
        Game g = new Game();
        g.play();
    }
}
