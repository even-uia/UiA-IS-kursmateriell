package game.items;

import game.Player;



/**
 * Write a description of class Book here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class MiniBank extends GameItem implements Usable
{
    public MiniBank() {
        super(BANK_NAME, BANK_DESC, false);
    }
    
    
    public void use(Player p) {
        if (p.hasItem(CARD_NAME)) {
            System.out.println(BANK_MSG);
            p.addItem(new GameItem(MONEY_NAME, MONEY_DESC, true));
        }
        else System.out.println(BANK_NOCARD_MSG);
    }
}
