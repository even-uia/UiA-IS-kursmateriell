package game.items;

import game.Player;



/**
 * Write a description of class Lecturer here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Lecturer extends GameItem implements Usable {

    public Lecturer() {
        super(LECTURER_NAME, LECTURER_DESC, false);
    }


    public void use(Player p) {
        if (! p.hasItem(NOTES_NAME)) {
            System.out.println(LECTURER_USE_MSG);
            if (p.hasItem(THEORY_NAME)) {
                p.addItem(new GameItem(NOTES_NAME, NOTES_DESC, true));
                System.out.println(LECTURER_NOTES_MSG);
            }
            else System.out.println(LECTURER_NOTHEORY_MSG);
        }
        else System.out.println(LECTURER_AGAIN_MSG);
    }
}
