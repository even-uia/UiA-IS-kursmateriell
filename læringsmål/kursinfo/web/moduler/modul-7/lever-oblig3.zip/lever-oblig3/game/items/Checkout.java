package game.items;

import game.Player;

/**
 * Write a description of class Checkout here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Checkout extends GameItem implements Usable
{
    public Checkout() {
        super(CHECKOUT_NAME, CHECKOUT_DESC, false);
    }
    
    
    public void use(Player p) {
        if (p.removeItem(MONEY_NAME) != null) {
            System.out.println(CHECKOUT_MSG);
            p.addItem(new Book());
        }
        else System.out.println(CHECKOUT_NOMONEY_MSG);
    }

    
}
