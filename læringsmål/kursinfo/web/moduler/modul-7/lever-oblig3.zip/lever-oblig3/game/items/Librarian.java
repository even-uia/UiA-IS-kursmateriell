package game.items;

import game.Player;

/**
 * Write a description of class Checkout here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Librarian extends GameItem implements Usable
{
    public Librarian() {
        super(LIBRARIAN_NAME, LIBRARIAN_DESC, false);
    }
    
    
    public void use(Player p) {
        System.out.println(LIBRARIAN_MSG);
        p.addItem(new Book());
    }

    
}
