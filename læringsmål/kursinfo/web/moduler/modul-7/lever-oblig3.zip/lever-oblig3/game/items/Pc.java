package game.items;

import game.Player;



/**
 *
 * @author Even �by Larsen (even.larsen@uia.no)
 */
public class Pc extends GameItem implements Usable {

    public Pc() {
        super(PC_NAME, PC_DESC, false);
    }


    public void use(Player p) {
        System.out.println(PC_USE_MSG);

        if (! p.hasItem(NOTES_NAME))
            System.out.println(PC_NOTES_MSG);
        else if (! p.hasItem(HINT_NAME)){
            p.addItem(new GameItem(ATTEMPT_NAME, ATTEMPT_DESC, true));
            System.out.println(PC_ATTEMPT_MSG);
        }
        else {
            p.setGameOver(true);
            System.out.println(PC_SUCCESS_MSG);
        }
    }
}
