package game.web;



/**
 *
 * @author Even �by Larsen (even.larsen@uia.no)
 */
public class RunGame {

    public final static long serialVersionUID = 1;

    
}
