package game;

import game.items.GameItem;
import java.util.Random;
import game.world.Location;
import game.items.Usable;

/**
 * A teaching Assistant that tries to find his way between two
 * rooms (by taking random exits from his current room.
 *
 * @author Even
 * @version 2008
 */
public class Assistant extends Actor implements Usable 
{
    private Location target, oldTarget;
    private Random rnd;

    /**
     * Constructor for objects of class Assistant.
     * @param start the starting room for the teaching assistant.
     * @param target the room he will try to move to.
     */
    public Assistant(Location start, Location target) {
        super(ASSISTANT_NAME, ASSISTANT_DESC, start);
        this.target = target;
        oldTarget = start;
        rnd = new Random();
    }

    /** Move to another room. */
    public void move() {
        if (getLocation() == target) { // he's found it - turn around
            target = oldTarget;
            oldTarget = getLocation();
        }
        else {
            Object[] exits = getLocation().getExits().toArray();
            int index = rnd.nextInt(2*exits.length);
            if (index < exits.length) {
                Location newLoc = getLocation().getExit((String)(exits[index]));

                if (getLocation().getItem(PLAYER_NAME) != null)
                    System.out.println(ASSISTANT_LEAVE_MSG);
                if (newLoc.getItem(PLAYER_NAME) != null)
                    System.out.println(ASSISTANT_ENTER_MSG);

                setLocation(newLoc);
            }
        }
    }
    
    
    /** Implement usable */
    public void use(Player p) {
        System.out.println(ASSISTANT_USE_MSG);
        if (! p.hasItem(BOOK_NAME))
            System.out.println(ASSISTANT_BOOK_MSG);
        else if (!  p.hasItem(THEORY_NAME))
            System.out.println(ASSISTANT_THEORY_MSG);
        else if (!  p.hasItem(NOTES_NAME))
            System.out.println(ASSISTANT_NOTES_MSG);
        else if (!  p.hasItem(ATTEMPT_NAME))
            System.out.println(ASSISTANT_ATTEMPT_MSG);
        else if (!  p.hasItem(HINT_NAME)) {
            p.addItem(new GameItem(HINT_NAME, HINT_DESC, true));
            System.out.println(ASSISTANT_HINT_MSG);
        }
        else System.out.println(ASSISTANT_DONE_MSG);
    }
}
