package game.commands;

import java.util.ArrayList;
import game.items.GameItem;
import game.Player;



/**
 * This class is part of the game 'Hand in the assignment'.
 *
 * The command class represents commands that can be executed by an interactive
 * player. It is an abstract class. The actual commands are executed as
 * subclasses.
 *
 * @author  Even �by Larsen
 * @version 2006.03.30
 */

public abstract class Command extends GameItem {

    /**
     * Initialize and register a new command.
     *
     * @param name the command name.
     * @param description command description.
     */
    public Command(String name, String description) {
        super(name, description, false);
    }


    /** Utf�r denne kommandoen for en bestemt spiller */
    public abstract void execute(Player p, ArrayList<String> commandLine);


    /** Hjelpemetode for � finne en ting */
    protected GameItem findItem(String name, Player p) {
        GameItem item;

        item = p.getItem(name);
        if (item != null) return item;
        item = p.getLocation().getItem(name);
        return item;
    }
}

