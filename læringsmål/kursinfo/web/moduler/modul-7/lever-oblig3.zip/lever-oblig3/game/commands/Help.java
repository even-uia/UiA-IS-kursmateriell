package game.commands;

import java.util.ArrayList;
import game.Player;



/**
 * Help gir hjelp. Enten kommandolisten,
 * eller detaljer om en kommando.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Help extends Command
{
    public Help() {
        super(HELP_NAME, HELP_DESC);
    }
    
    
    public void execute(Player p, ArrayList<String> cmdLine) {
        CommandList commands = CommandList.getInstance();
        String cmdName = null;

        if (cmdLine.size() == 2 &&
            HELP_NAME.equals(cmdLine.get(0))) {
            //user is asking for help
            cmdName = cmdLine.get(1);
        }
        else {
            // user has messed up command line syntax
            cmdName = cmdLine.get(0);
        }
        Command cmd = commands.getCommand(cmdName);
        if (cmd != null) System.out.println(cmd.getDescription());
        else {
            System.out.println(HELP_NOCMD_MSG+cmdName);
            System.out.println(HELP_AVAIL_MSG);
            commands.showAll();
            System.out.println(HELP_INFO_MSG);
        }
    }
}
