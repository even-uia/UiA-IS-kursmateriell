package game.commands;

import java.util.ArrayList;
import game.Player;



/**
 * Write a description of class Inventory here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Inventory extends Command
{
    public Inventory() {
        super(INVENTORY_NAME, INVENTORY_DESC);
    }
    
    
    public void execute(Player p, ArrayList<String> cmdLine) {
        System.out.println(p.getInventoryString());
    }
}
