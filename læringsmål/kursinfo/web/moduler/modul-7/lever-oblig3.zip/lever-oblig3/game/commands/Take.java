package game.commands;

import java.util.ArrayList;
import game.Player;
import game.items.GameItem;



/**
 * Write a description of class Take here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Take extends Command
{
    public Take() {
        super(TAKE_NAME, TAKE_DESC);
    }
    
    
    public void execute(Player p, ArrayList<String> cmdLine) {
        if (cmdLine.size() == 2) {
            GameItem item = p.getLocation().getItem(cmdLine.get(1));

            if (item != null) {
                if (item.isMovable()) {
                    p.getLocation().removeItem(item);
                    p.addItem(item);
                    System.out.println(TAKE_MSG+item.getName());
                }
                else {
                    System.out.print(TAKE_HEAVY_MSG1);
                    System.out.print(item.getName());
                    System.out.println(TAKE_HEAVY_MSG2);
                }
            }
            else System.out.println(TAKE_NOITEM_MSG);
        }
        else System.out.println(TAKE_ONEITEM_MSG);
    }
}
