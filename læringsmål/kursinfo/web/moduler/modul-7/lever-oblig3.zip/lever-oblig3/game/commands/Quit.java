package game.commands;

import java.util.ArrayList;
import game.Player;

/**
 * Write a description of class Quit here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Quit extends Command
{
    public Quit() {
        super(QUIT_NAME, QUIT_DESC);
    }
    
    
    public void execute(Player p, ArrayList<String> cmdLine) {
        p.setGameOver(true);
    }
}
