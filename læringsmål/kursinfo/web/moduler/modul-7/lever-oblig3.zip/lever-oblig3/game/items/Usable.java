package game.items;


import game.Player;


/**
 * Write a description of class Usable here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public interface Usable {
    public void use(Player p);
}
