package game.commands;

import java.util.HashMap;

/**
 * This class is part of the game 'Hand in the assignment'.
 *
 * The CommandWords class is a singleton that manages the available commands
 * in the game.
 *
 * @author  Michael Kolling and David J. Barnes
 * @version 2006.03.30
 */

public class CommandList
{
    /** The one and only CommandWords instance */
    private static CommandList instance = null;

    /** The command table */
    private HashMap<String, Command> validCommands;

    /**
     * Constructor is private - to prevent additional CommandWords objects from
     * being created.
     */
    private CommandList()
    {
        validCommands = new HashMap<String, Command>();
        addCommand(new Help());
        addCommand(new Go());
        addCommand(new Inspect());
        addCommand(new Take());
        addCommand(new Inventory());
        addCommand(new Use());
        addCommand(new Quit());
    }


    /** Add a command.
     * @param name the command name.
     * @param command the new command object.
     */
    public void addCommand(Command command) {
        validCommands.put(command.getName(), command);
    }


    /**
     * Find a Command by name.
     * @param commandWord the command naame.
     * @return the Command object, or null if no command
     * matching the name exists.
     */
    public Command getCommand(String commandWord)
    {
        return validCommands.get(commandWord);
    }

    /**
     * Check if a command name is valid.
     * @param commandName the command name to check.
     * @return true if it is, false if it isn't.
     */
    public boolean isCommand(String commandName)
    {
        return validCommands.containsKey(commandName);
    }

    /**
     * Print all valid commands to System.out.
     */
    public void showAll()
    {
        for(String command : validCommands.keySet()) {
            System.out.print(command + " ");
        }
        System.out.println();
    }


    /** Return the only CommandWords instance */
    public static CommandList getInstance() {
        if (instance == null) {
            instance = new CommandList();
        }
        return instance;
    }
}
