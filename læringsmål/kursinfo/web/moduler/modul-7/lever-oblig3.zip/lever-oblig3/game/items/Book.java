package game.items;

import game.Player;



/**
 * Write a description of class Book here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Book extends GameItem implements Usable
{
    public Book() {
        super(BOOK_NAME, BOOK_DESC, true);
    }
    
    
    public void use(Player p) {
        System.out.println(BOOK_MSG);
        p.addItem(new GameItem(THEORY_NAME, THEORY_DESC, true));
    }
}
