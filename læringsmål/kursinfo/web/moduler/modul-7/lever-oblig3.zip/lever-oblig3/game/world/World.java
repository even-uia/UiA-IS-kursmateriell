package game.world;

import java.util.HashMap;

import game.world.Location;
import game.GameConstants;
import game.items.*;



/**
 * The game World.
 *
 * @author Even �by Larsen
 * @version 1.0
 */
public class World implements GameConstants {
    private HashMap<String,Location> locations;


    public World() {
        locations = createLocations();
    }


    /** Get the location with specified name */
    public Location getLocation(String name) {
        return locations.get(name);
    }


    /** Add a named location */
    public void addLocation(String name, Location loc) {
        locations.put(name, loc);
    }


    /** Create and add a location */
    public void addLocation(String name, String description, String preposition) {
        Location loc = new Location(name, description, preposition);
        locations.put(name, loc);
    }


    /** Remove and return a location */
    public Location removeLocation(String name) {
        return locations.remove(name);
    }


    /** Create the world */
    private HashMap<String,Location> createLocations() {
        locations = new HashMap<String,Location>();

        Location loc;

        addLocation(ENTR_NAME, ENTR_DESC, ENTR_PREP);
        addLocation(CAFE_NAME,CAFE_DESC, CAFE_PREP);
        addLocation(SHOP_NAME, SHOP_DESC, SHOP_PREP);
        addLocation(HALL_NAME, HALL_DESC, HALL_PREP);
        addLocation(LIB_NAME, LIB_DESC, LIB_PREP);
        addLocation(BRDG_NAME, BRDG_DESC, BRDG_PREP);
        addLocation(LAB_NAME, LAB_DESC, LAB_PREP);
        addLocation(AUD_NAME, AUD_DESC, AUD_PREP);

        loc = locations.get(ENTR_NAME);
        loc.setExit(DIR_UP, locations.get(HALL_NAME));
        loc.setExit(DIR_EAST, locations.get(SHOP_NAME));
        loc.setExit(DIR_WEST, locations.get(CAFE_NAME));

        loc = locations.get(CAFE_NAME);
        loc.addItem(new GameItem(CARD_NAME, CARD_DESC, true));
        loc.setExit(DIR_EAST, locations.get(ENTR_NAME));

        loc = locations.get(SHOP_NAME);
        loc.addItem(new Checkout());
        loc.setExit(DIR_WEST, locations.get(ENTR_NAME));

        loc = locations.get(HALL_NAME);
        loc.addItem(new MiniBank());
        loc.setExit(DIR_DOWN, locations.get(ENTR_NAME));
        loc.setExit(DIR_WEST, locations.get(LIB_NAME));
        loc.setExit(DIR_UP, locations.get(BRDG_NAME));

        loc = locations.get(LIB_NAME);
        loc.addItem(new Librarian());
        loc.setExit(DIR_EAST, locations.get(HALL_NAME));
        loc.setExit(DIR_DOWN, locations.get(CAFE_NAME));

        loc = locations.get(BRDG_NAME);
        loc.setExit(DIR_DOWN, locations.get(HALL_NAME));
        loc.setExit(DIR_EAST, locations.get(AUD_NAME));
        loc.setExit(DIR_WEST, locations.get(LAB_NAME));

        loc = locations.get(LAB_NAME);
        loc.addItem(new Pc());
        loc.setExit(DIR_EAST, locations.get(BRDG_NAME));
        loc.setExit(DIR_DOWN, locations.get(CAFE_NAME));

        loc = locations.get(AUD_NAME);
        loc.addItem(new Lecturer());
        loc.setExit(DIR_WEST, locations.get(BRDG_NAME));
        loc.setExit(DIR_DOWN, locations.get(SHOP_NAME));

        return locations;
    }
}
