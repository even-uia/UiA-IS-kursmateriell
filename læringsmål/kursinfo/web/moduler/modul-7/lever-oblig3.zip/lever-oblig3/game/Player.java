package game;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import game.items.GameItem;
import game.world.Location;
import game.commands.Command;
import game.commands.CommandList;



/**
 * The Player class handles all user interaction. When it is the user's
 * turn to move, the Player object reads a command line from the keyboard,
 * parses it, and executes it.
 * 
 * The player object also keeps track of the user's progress in the game.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Player extends Actor
{
    private CommandParser parser;
    private CommandList commands;

    /** The places the player has been, used for smarter descriptions */
    private HashSet<Location> visited;

    /** The things the player is carrying */
    private HashMap<String,GameItem> items;

    private boolean gameOver;
    
    public Player(Location loc) {
        super(PLAYER_NAME, PLAYER_DESC, loc);
            
        parser = new CommandParser();
        commands = CommandList.getInstance();
        visited = new HashSet<Location>();
        items = new HashMap<String,GameItem>();
        gameOver = false;
    }
    
    
    /** Execute one command. */
    public void move() {
        visited.add(getLocation());
        ArrayList<String> cmdLine = parser.getCommand();
System.out.println("cmdlin "+cmdLine);
        Command cmd = commands.getCommand(cmdLine.get(0));
System.out.println("cmd = "+cmd);
        
        if (cmd == null) cmd = commands.getCommand(HELP_NAME);
System.out.println("cmd = "+cmd);
        cmd.execute(this, cmdLine);
    }
    
    
    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }
    
    
    /** Gi en ting til spilleren */
    public void addItem(GameItem item) {
        items.put(item.getName(), item);
    }
    
    
    /** Se p� en ting spilleren har */
    public GameItem getItem(String name) {
        return items.get(name);
    }


    /** Sjekk om spilleren har en ting */
    public boolean hasItem(String name) {
        GameItem item = getItem(name);
        return item != null;
    }
    
    
    /** Ta en ting fra spilleren */
    public GameItem removeItem(String name) {
        return items.remove(name);
    }


    public String getInventoryString() {
        StringBuilder buf = new StringBuilder();
        buf.append(MSG_INVENTORY);
        for (String n : items.keySet()) {
            buf.append(" ");
            buf.append(n);
        }
        buf.append(".");
        return buf.toString();
    }


    /** Return true if the player have visited the specified location */
    public boolean hasVisited(Location loc) {
        return visited.contains(loc);
    }
    
    
    /** Return true if the player has won the game,
     * or wants to quit.
     */
    public boolean checkStatus() {        
//        if (getLocation().getName() == SHOP_NAME && !hasBook) {
//             System.out.println(MSG_BUY_BOOK);
//             hasBook = true;
//         }
//         else if (getLocation().getName() == LIB_NAME  && !hasBook) {
//             System.out.println(MSG_LOAN_BOOK);
//             hasBook = true;
//         }
//         else if (getLocation().getName() == AUD_NAME) {
//             if (heardLecture) System.out.println(MSG_LECTURE_REP);
//             else if (hasBook) {
//                 System.out.println(MSG_LECTURE);
//                 heardLecture = true;
//             }
//             else {
//                 System.out.println(MSG_LECTURE_NOBOOK);
//             }
//         }
//         else if (getLocation().getName() == LAB_NAME) {
//             if (hasBook) {
//                 visitedLab = true;
//                 if (askedAssistant && heardLecture) {
//                     System.out.println(MSG_FINISHED);
//                     gameOver = true;
//                 }
//                 else if (askedAssistant) {
//                     System.out.println(MSG_NOLECTURE);
//                 }
//                 else if (heardLecture) {
//                     System.out.println(MSG_NOASSISTANT);
//                 }
//                 else {
//                     System.out.println(MSG_NEED_HELP);
//                 }
//             }
//             else {
//                 System.out.println(MSG_NOBOOK);
//             }
//         }
//
//         if (getLocation().getItem(ASSISTANT_NAME) != null) {
//             if (visitedLab && !askedAssistant) {
//                 System.out.println(MSG_ASSISTANT);
//                 askedAssistant = true;
//             }
//         }
        
        return gameOver;
    }


    public boolean gameOver() { return gameOver; }
}
