package game.commands;

import java.util.ArrayList;
import game.Player;
import game.items.GameItem;



/**
 * Write a description of class Inspect here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Inspect extends Command
{
    public Inspect() {
        super(EXAMINE_NAME, EXAMINE_DESC);
    }
    
    
    public void execute(Player p, ArrayList<String> cmdLine) {
        String desc = null;
        if (cmdLine.size() == 1)
            System.out.println(p.getLocation().getLongDescription());
        else if (cmdLine.size() == 2) {
            GameItem item = findItem(cmdLine.get(1), p);
            
            if (item != null) System.out.println(item.getDescription());
            else System.out.println(EXAMINE_NOITEM_MSG);
        }
        else System.out.println(EXAMINE_TOOMANY_MSG);
    }
}
