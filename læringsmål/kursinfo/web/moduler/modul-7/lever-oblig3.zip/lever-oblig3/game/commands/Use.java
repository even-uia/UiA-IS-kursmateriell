package game.commands;

import java.util.ArrayList;
import game.Player;
import game.items.GameItem;
import game.items.Usable;



/**
 * Write a description of class Use here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class Use extends Command
{
    public Use() {
        super(USE_NAME, USE_DESC);
    }
    
    
    public void execute(Player p, ArrayList<String> cmdLine) {
        if (cmdLine.size() < 2) System.out.println(USE_WHAT_MSG);
        else if (cmdLine.size() > 2) System.out.println(USE_MANY_MSG);
        else {
            GameItem item = findItem(cmdLine.get(1), p);
            if (item instanceof Usable)
                ((Usable)item).use(p);
            else System.out.println(USE_UNUSABLE_MSG);
        }
    }
}
