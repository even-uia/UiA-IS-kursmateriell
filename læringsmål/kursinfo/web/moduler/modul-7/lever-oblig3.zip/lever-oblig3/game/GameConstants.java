package game;


/**
 * Write a description of interface GameConstants here.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */

public interface GameConstants {
    // Here are String constants for all text displayed
    // by the game.
    // Using these constants makes it easier to translate
    // the game (this is the only file that needs changing)
    // and it ensures that the language is consistent throughout

    // Locations
    public static final String ENTR_NAME = "inngangen";
    public static final String ENTR_DESC = "Det er d�rer til alle kanter, og ei lang trapp.";
    public static final String ENTR_PREP = "ved";
    public static final String CAFE_NAME = "kantina";
    public static final String CAFE_DESC = "Her kan du f� kaffe og noe � spise.";
    public static final String CAFE_PREP = "i";
    public static final String SHOP_NAME = "bokhandelen";
    public static final String SHOP_DESC = "Her kan du kj�pe l�reboka.";
    public static final String SHOP_PREP = "i";
    public static final String HALL_NAME = "Vrimlehallen";
    public static final String HALL_DESC = "Dette er en stor hall med glasstak.";
    public static final String HALL_PREP = "i";
    public static final String LIB_NAME = "biblioteket";
    public static final String LIB_DESC = "Her kan du l�ne l�reboka.";
    public static final String LIB_PREP = "i";
    public static final String BRDG_NAME = "gangbrua";
    public static final String BRDG_DESC = "Du ser ned p� Vrimlehallen.";
    public static final String BRDG_PREP = "p�";
    public static final String LAB_NAME = "laben";
    public static final String LAB_DESC = "Her er det mange PCer. Du kan jobbe med oppgaven her.";
    public static final String LAB_PREP = "p�";
    public static final String AUD_NAME = "auditoriet";
    public static final String AUD_DESC = "Hallgeir og Even snakker om programmering.";
    public static final String AUD_PREP = "i";

    // Directions
    public static final String DIR_UP = "opp";
    public static final String DIR_DOWN = "ned";
    public static final String DIR_EAST = "�st";
    public static final String DIR_WEST = "vest";
    public static final String DIR_NORT = "nord";
    public static final String DIR_SOUT = "s�r";
    
    // Commands
    public static final String HELP_NAME = "hjelp";
    public static final String HELP_DESC = "hjelp - Skriv ut liste over kommandoer,\n"
            +"hjelp <kommando> - Vis hjelp for angitt kommando";
    public static final String HELP_NOCMD_MSG = "Finner ikke kommandoen ";
    public static final String HELP_AVAIL_MSG = "Kommandoene du kan bruke er:";
    public static final String HELP_INFO_MSG = "Bruk 'hjelp <kommando>' for � f� mer hjelp.";
    public static final String GO_NAME = "gaa";
    public static final String GO_DESC = "gaa <retning> - G� til naborommet i angitt retning.";
    public static final String GO_NOEXIT_MSG = "Du kan ikke g� ";
    public static final String GO_NOEXIT_MSG2 = " herfra!";
    public static final String GO_NODIR_MSG = "G� hvor?";
    public static final String EXAMINE_NAME = "se";
    public static final String EXAMINE_DESC = "se - Se n�rmere p� stedet du er.\n"
            +"se <ting> - Se n�rmere p� en ting.";
    public static final String EXAMINE_NOITEM_MSG = "Pr�v � se p� noe som finnes.";
    public static final String EXAMINE_TOOMANY_MSG = "Se p� en ting av gangen.";
    public static final String TAKE_NAME = "ta";
    public static final String TAKE_DESC = "ta - Ta en ting.";
    public static final String TAKE_MSG = "Du tar ";
    public static final String TAKE_HEAVY_MSG1 = "Du fors�ker � l�fte ";
    public static final String TAKE_HEAVY_MSG2 = ", men det er nyttel�st.\n"
            +"Det eneste du har f�tt er vondt i ryggen.";
    public static final String TAKE_NOITEM_MSG = "Kan ikke ta det.";
    public static final String TAKE_ONEITEM_MSG = "Pr�v � ta en ting.";
    public static final String INVENTORY_NAME = "har";
    public static final String INVENTORY_DESC = "har - List tingene du har tatt.";
    public static final String MSG_INVENTORY = "Du har:";
    public static final String USE_NAME = "bruk";
    public static final String USE_DESC = "bruk - Bruk en ting.";
    public static final String USE_WHAT_MSG = "Bruk hva da?";
    public static final String USE_MANY_MSG = "Du kan bare bruke en ting av gangen";
    public static final String USE_UNUSABLE_MSG = "Du kan ikke bruke det der."   ;
    public static final String QUIT_NAME = "slutt";
    public static final String QUIT_DESC = "slutt - Avslutt spillet.";
    
    // Assistant
    public static final String ASSISTANT_NAME = "hjelpel�rer";
    public static final String ASSISTANT_DESC = "Hjelpel�reren svarer p� sp�rsm�l og retter obligene.";
    public static final String ASSISTANT_ENTER_MSG = "Hjelpel�reren kommer inn.";
    public static final String ASSISTANT_LEAVE_MSG = "Hjelpel�reren g�r ut.";
    public static final String ASSISTANT_USE_MSG = "Du sp�r hjelpel�reren om hjelp.";
    public static final String ASSISTANT_BOOK_MSG = "Han sier du m� f� tak i boka.\nDen finnes i bokhandelen og biblioteket.";
    public static final String ASSISTANT_THEORY_MSG = "Han sier du m� lese boka.";
    public static final String ASSISTANT_NOTES_MSG = "Han sier du m� g� p� forelesniing.";
    public static final String ASSISTANT_ATTEMPT_MSG = "Han sier du m� pr�ve selv f�rst.\nG� p� laben.";
    public static final String ASSISTANT_HINT_MSG = "Han gir deg et hint.\nG� p� laben og pr�v igjen.";
    public static final String ASSISTANT_DONE_MSG = "Han sier du har f�tt nok hjelp.\nG� p� laben.";
    
    // Player
    public static final String PLAYER_NAME = "Du";
    public static final String PLAYER_DESC = "Du er en student som skal levere obligen i programmering.";
    
    // Plot Items
    public static final String CARD_NAME = "bankkort";
    public static final String CARD_DESC = "Det er bankkortet ditt.";
    public static final String BANK_NAME = "minibank";
    public static final String BANK_DESC = "I minibanken kan du ta ut penger.";
    public static final String BANK_MSG = "Du tar ut penger i minibanken.";
    public static final String BANK_NOCARD_MSG = "Du finner ikke bankkortet.\nDu m� ha mistet det.";
    public static final String MONEY_NAME = "penger";
    public static final String MONEY_DESC = "Du kan betale med penger.";
    public static final String CHECKOUT_NAME = "kasse";
    public static final String CHECKOUT_DESC = "I kassa kan du kj�pe l�reboka.";
    public static final String CHECKOUT_MSG = "Du tar l�reboka og betaler i kassa.";
    public static final String CHECKOUT_NOMONEY_MSG = "Kassadamen tar boka fra deg\n"
            +"og sier du m� komme igjen n�r du har penger � betale med.";
    public static final String LIBRARIAN_NAME = "bibliotekar";
    public static final String LIBRARIAN_DESC = "Bibliotekaren kan finne b�ker for deg.";
    public static final String LIBRARIAN_MSG = "Du sp�r bibliotekaren etter l�reboka, og han finner den for deg.";
    public static final String BOOK_NAME = "l�rebok";
    public static final String BOOK_DESC = "Objects first with BlueJ, av Barnes og K�lling";
    public static final String BOOK_MSG = "Du leser l�reboka, og begynner � f� tak p� teorien";
    public static final String THEORY_NAME = "teori";
    public static final String THEORY_DESC = "Teorien har du l�rt ved � lese boka.";
    public static final String LECTURER_NAME = "foreleser";
    public static final String LECTURER_DESC = "Foreleseren forklarer teorien fra l�reboka.";
    public static final String LECTURER_USE_MSG = "Du setter deg ned og h�rer p� forelesningen.";
    public static final String LECTURER_NOTES_MSG = "Du tar notater underveis. Du forst�r teorien mye bedre n�.";
    public static final String LECTURER_NOTHEORY_MSG = "Du skj�nner ingenting. Du burde lese boka f�rst.";
    public static final String LECTURER_AGAIN_MSG = "Du har v�rt p� forelesning.\nDu b�r heller g� p� laben.";
    public static final String NOTES_NAME = "notater";
    public static final String NOTES_DESC = "Notatene dine fra forelesningen.\n"
            +"Med notatene og l�reboka kan du ta fatt p� obligen.";
    public static final String PC_NAME = "pc";
    public static final String PC_DESC = "Lab-pcene er lenket fast.\nDu kan bruke dem til � l�se obligen.";
    public static final String PC_USE_MSG = "Du setter deg ned ved en PC.";
    public static final String PC_NOTES_MSG = "Du vet ikke hvordan du skal komme igang med obligen.\n"
            +"Du m� lese boka og g� p� forelesning f�rst.";
    public static final String PC_ATTEMPT_MSG = "Du gj�r et fors�k, men f�r det ikke helt til.\n"
            +"Du m� finne hjelpel�reren og be om hjelp.";
    public static final String PC_SUCCESS_MSG = "Denne gangen l�ser du obligen uten problemer.\n"
            +"Du logger inn i ClassFronter og leverer obligen.\n"
            +"Gratulerer du har klart det!";
    public static final String ATTEMPT_NAME = "fors�k";
    public static final String ATTEMPT_DESC = "Resultatet av f�rste forrs�k p� � l�se obligen.";
    public static final String HINT_NAME = "hint";
    public static final String HINT_DESC = "Et godt r�d du fikk av hjelpel�reren.";


    // Messages
    public static final String MSG_BYE = "Takk for at du spilte. Ha det bra!";
    public static final String MSG_WELCOME = "Velkommen til spillet \"Oblig\"!\n"
            +"\nM�let ditt er � f� levert obligen i IS-102";    
}
