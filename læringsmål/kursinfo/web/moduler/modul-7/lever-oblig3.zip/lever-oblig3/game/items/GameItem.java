package game.items;


import game.GameConstants;


/**
 * Common superclass for everything in the game world.
 * 
 * @author Even �by Larsen
 * @version 1.0
 */
public class GameItem implements GameConstants
{
    
    /** The name, or short description of the item */
    private String name;
    
    /** A longer description of the item. */
    private String description;
    
    /** Kan spilleren ta denne tingen */
    private boolean movable;
    
    
    public GameItem(String name, String description, boolean movable) {
        this.name = name;
        this.description = description;
        this.movable = movable;
    }
    
    
    public String getName() {
        return name;
    }
    
    
    public String getDescription() {
        return description;
    }
    
    
    /** Return true if this item can be taken by the player */
    public boolean isMovable() {
        return movable;
    }
}
